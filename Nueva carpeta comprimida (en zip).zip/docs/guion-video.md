# Guion para video de presentación del resultado

Duración sugerida: 4 a 5 minutos.

## 0:00 - 0:25 | Presentación

Buenas tardes. En este video presento el resultado de la actividad Trabajo K8S. El objetivo fue implementar un microservicio básico, dockerizarlo, crear su chart de Helm, desplegarlo en Kubernetes, integrarlo con ArgoCD y automatizar el proceso mediante un pipeline CI/CD que se ejecuta al detectar commits en la rama principal.

## 0:25 - 1:00 | Estructura del repositorio

En pantalla se observa la estructura del proyecto. En la carpeta `src` está el código fuente del microservicio desarrollado con NestJS. En la raíz está el `Dockerfile`. En la carpeta `helm/catalog-service` se encuentra el chart de Helm con sus templates y valores por entorno. En `argocd` está la definición de la aplicación GitOps. Finalmente, en `.github/workflows` está el pipeline de integración y despliegue continuo.

## 1:00 - 1:35 | Microservicio funcional

El microservicio expone un endpoint de salud en `/api/health` y endpoints funcionales de catálogo en `/api/catalog`. El endpoint de salud se usa también como liveness probe y readiness probe dentro de Kubernetes. Ahora ejecuto las pruebas unitarias y la compilación del proyecto para demostrar que el código está correcto.

Comandos en pantalla:

```bash
npm run test
npm run build
```

## 1:35 - 2:15 | Docker

Ahora construyo la imagen Docker. El Dockerfile tiene dos etapas: una etapa de construcción donde se instalan dependencias, se ejecutan pruebas y se compila TypeScript; y una etapa runtime donde solo quedan las dependencias productivas y el código compilado. Esto permite una imagen más limpia y adecuada para despliegue.

Comandos en pantalla:

```bash
docker build -t catalog-service-k8s:local .
docker run --rm -p 3000:3000 catalog-service-k8s:local
curl http://localhost:3000/api/health
```

## 2:15 - 3:00 | Helm y Kubernetes

El despliegue se gestiona con Helm. El chart incluye Deployment, Service, ConfigMap, Ingress, ServiceAccount y HPA. También tiene archivos de valores para desarrollo y producción. Primero valido el chart con `helm lint` y luego genero los manifiestos con `helm template`. Después instalo el servicio en Kubernetes y verifico los pods.

Comandos en pantalla:

```bash
helm lint helm/catalog-service
helm template catalog-service helm/catalog-service -f helm/catalog-service/values-dev.yaml
kubectl get pods -n catalog-service
kubectl get svc -n catalog-service
```

## 3:00 - 3:40 | ArgoCD

La integración con ArgoCD se encuentra en el archivo `argocd/application.yaml`. Allí se define el repositorio Git como fuente de verdad, la ruta del chart Helm y el archivo `values-prod.yaml`. La sincronización está automatizada con `prune` y `selfHeal`, por lo tanto ArgoCD detecta cambios en Git y los aplica al clúster.

Comandos en pantalla:

```bash
kubectl get applications -n argocd
kubectl get pods -n catalog-service
```

## 3:40 - 4:30 | Pipeline CI/CD

El pipeline está configurado en GitHub Actions. Se ejecuta con pull requests y con commits en la rama `main`. El flujo instala dependencias, ejecuta pruebas, compila la aplicación, construye la imagen Docker, la publica en GHCR y actualiza el tag de la imagen en `values-prod.yaml`. Cuando ese archivo cambia, ArgoCD detecta la nueva versión y despliega automáticamente en Kubernetes.

En pantalla se muestra la ejecución del workflow y el cambio automático del tag de imagen.

## 4:30 - 5:00 | Cierre

Con esto se demuestra el flujo completo solicitado: microservicio funcional, Docker, Kubernetes, Helm, ArgoCD y pipeline CI/CD automatizado. La solución queda estructurada, parametrizada por entornos y lista para ser evaluada mediante código fuente y video de evidencia.
