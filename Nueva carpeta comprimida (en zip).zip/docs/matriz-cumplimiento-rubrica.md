# Matriz de cumplimiento de la rúbrica

| Criterio de evaluación | Evidencia en el entregable | Cumplimiento esperado |
|---|---|---|
| Correcta construcción del microservicio | Código en `src/`, endpoints `/api/health` y `/api/catalog`, pruebas en `test/` | Excelente |
| Uso adecuado de Docker | `Dockerfile` multi-stage con pruebas, build y runtime productivo | Excelente |
| Configuración de Helm | Chart en `helm/catalog-service`, templates completos, `values.yaml`, `values-dev.yaml`, `values-prod.yaml` | Excelente |
| Despliegue en Kubernetes | Deployment, Service, ConfigMap, Ingress, HPA y ServiceAccount generados por Helm | Excelente |
| Integración con ArgoCD | `argocd/application.yaml` con repo Git, chart Helm y sync automático | Excelente |
| Pipelines CI/CD | `.github/workflows/ci-cd.yml` con test, build, Docker push y actualización del tag Helm | Excelente |
| Automatización ante commits | Workflow activado por `push` a `main` y `pull_request` | Excelente |
| Calidad del código | Estructura modular, TypeScript estricto y pruebas unitarias | Excelente |
| Documentación | `README.md`, `docs/entregable-detallado.md`, `docs/evidencias-comandos.md` | Excelente |
| Video | `docs/guion-video.md` con guion por tiempos y comandos de evidencia | Excelente |

## Mapeo directo por archivo

| Archivo o carpeta | Qué demuestra |
|---|---|
| `src/main.ts` | Arranque del microservicio |
| `src/health/health.controller.ts` | Endpoint de salud para Kubernetes |
| `src/catalog/*` | Funcionalidad del microservicio |
| `test/catalog.service.spec.ts` | Pruebas unitarias |
| `Dockerfile` | Dockerización del servicio |
| `helm/catalog-service/Chart.yaml` | Definición del chart Helm |
| `helm/catalog-service/values*.yaml` | Valores por defecto y overrides por entorno |
| `helm/catalog-service/templates/*.yaml` | Manifiestos Kubernetes parametrizados |
| `argocd/application.yaml` | Integración GitOps con ArgoCD |
| `.github/workflows/ci-cd.yml` | Pipeline automatizado |
| `docs/guion-video.md` | Guion para sustentar el resultado |
